﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Metadata;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace PluginsStem
{
    public class SetInductionStatus : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService orgService = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                Entity entity = (Entity)context.InputParameters["Target"];
                var entityID = entity.Id;

                if(context.MessageName == "Update" && (entity.Contains("sam_safeguardingcoursecompleted") || entity.Contains("sam_inductionvideowatched") || entity.Contains("sam_ambassadoragreementsigned") || entity.Contains("sam_profilecompleted")) )
                {
                    setInductionStatus(orgService, entityID);
                }

            }
            catch (Exception ex) 
            {
                throw new InvalidPluginExecutionException("Error in SetInductionStatus Plugin: " + ex.Message);
            }
        }

        public void setInductionStatus(IOrganizationService orgService, Guid id)
        {
            var contact = orgService.Retrieve("contact", id, new Microsoft.Xrm.Sdk.Query.ColumnSet("sam_safeguardingcoursecompleted", "sam_inductionvideowatched", "sam_ambassadoragreementsigned", "sam_profilecompleted"));
            
            var safeguardingCourseCompleted = contact.GetAttributeValue<bool>("sam_safeguardingcoursecompleted");
            var inductionVideoWatched = contact.GetAttributeValue<bool>("sam_inductionvideowatched");
            var ambassadorAgreementSigned = contact.GetAttributeValue<bool>("sam_ambassadoragreementsigned");
            var profileCompleted = contact.GetAttributeValue<bool>("sam_profilecompleted");

            var contactToUpdate = new Entity("contact");
            contactToUpdate.Id = id;

            if (safeguardingCourseCompleted && inductionVideoWatched && ambassadorAgreementSigned && profileCompleted)
            {
                contactToUpdate["sam_inductionstatus"] = new OptionSetValue(1);
            }
            else
            {
                contactToUpdate["sam_inductionstatus"] = new OptionSetValue(2);
            }

            orgService.Update(contactToUpdate);

        }
    }
    }

