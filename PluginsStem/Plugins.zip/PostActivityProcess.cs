﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsStem
{
    public class PostActivityProcess : IPlugin
    {
        #region Constants – entity & attribute logical names

        // Entities
        private const string ENTITY_ACTIVITY = "sam_ambassadoractivity";
        private const string ENTITY_ACTIVITYAMBASSADOR = "sam_activityambassador";
        private const string ENTITY_ACTIVITYFEEDBACK = "sam_activityfeedback";
        private const string ENTITY_NOTIFICATION = "sam_notification";
        private const string ENTITY_CONTACT = "contact";

        // Activity (sam_ambassadoractivity)
        private const string FIELD_ACTIVITY_ID = "activityid";
        private const string FIELD_ACTIVITY_SUBJECT = "subject";
        private const string FIELD_ACTIVITY_ENDDATE = "actualend";
        private const string FIELD_ACTIVITY_STATECODE = "statecode";
        private const string FIELD_ACTIVITY_STATUSCODE = "statuscode";

        // Activity Ambassador (sam_activityambassador)
        private const string FIELD_ACTIVITYAMB_ACTIVITY_LOOKUP = "sam_ambassadoractivity";
        private const string FIELD_ACTIVITYAMB_CONTACT_LOOKUP = "sam_ambassador";
        private const string FIELD_ACTIVITYAMB_STATECODE = "statecode";
        private const string FIELD_ACTIVITYAMB_STATUSCODE = "statuscode";

        // Activity Feedback (sam_activityfeedback)
        private const string FIELD_FEEDBACK_CONTACT_LOOKUP = "sam_contact";
        private const string FIELD_FEEDBACK_ACTIVITY_LOOKUP = "sam_activity";
        private const string FIELD_FEEDBACK_STATECODE = "statecode";
        private const string FIELD_FEEDBACK_STATUSCODE = "statuscode";
        private const string FIELD_FEEDBACK_ACTIVITYAMB_LOOKUP = "sam_activityambassador";

        // Notification (sam_notification)
        private const string FIELD_NOTIFICATION_SUBJECT = "subject";
        private const string FIELD_NOTIFICATION_TO = "to";
        private const string FIELD_NOTIFICATION_DESCRIPTION = "description";
        private const string FIELD_NOTIFICATION_REGARDING = "regardingobjectid";

        // Contact
        private const string FIELD_CONTACT_LAST_ACTIVITY = "sam_lastactivitydate";

        #endregion

        #region Constants – option set values

        // Activity state/status
        private const int ACTIVITY_STATE_OPEN = 0;
        private const int ACTIVITY_STATE_COMPLETED = 1;

        private const int ACTIVITY_STATUS_COMPLETED = 2;          // "Completed"
        private const int ACTIVITY_STATUS_DID_NOT_RUN = 999990001; // "Did not run"

        // Activity Ambassador state/status
        private const int ACTIVITYAMB_STATE_ACTIVE = 0;
        private const int ACTIVITYAMB_STATUS_INTEREST_REGISTERED = 999990001;
        private const int ACTIVITYAMB_STATUS_POSITION_ACCEPTED = 999990002;
        private const int ACTIVITYAMB_STATUS_AWAITING_FEEDBACK = 999990003;

        // Activity Feedback state/status
        private const int FEEDBACK_STATE_ACTIVE = 0;
        private const int FEEDBACK_STATUS_AWAITING = 1; 

        #endregion

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = null;

            try
            {
                var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                var orgService = serviceFactory.CreateOrganizationService(context.UserId);
                tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                if (context.Depth > 1)
                    return;

                Process(orgService, tracer);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error in PostActivityProcess Plugin: " + ex.Message, ex);
            }
        }


        /// Main process – finds activities whose end date has passed and performs
        /// all of the required downstream updates.
        public void Process(IOrganizationService orgService, ITracingService tracer = null)
        {
            // 1. Get all activities to process
            var activities = GetActivitiesToProcess(orgService);

            if (tracer != null)
                tracer.Trace("PostActivityProcess: Found {0} activities to process.", activities.Count);

            foreach (var activity in activities)
            {
                if (tracer != null)
                    tracer.Trace("Processing activity {0}", activity.Id);

                // 2. Get all activity ambassadors for this activity
                var ambassadors = GetActivityAmbassadors(orgService, activity.Id);

                // 3. Set activity status based on whether there are any active ambassadors
                SetActivityStatus(orgService, activity, ambassadors);

                // 4. Get ambassadors that are in “Interest Registered” or “Position Accepted”
                var ambassadorsForFeedback = ambassadors
                    .Where(a =>
                    {
                        var sc = a.GetAttributeValue<OptionSetValue>(FIELD_ACTIVITYAMB_STATUSCODE)?.Value ?? -1;
                        return sc == ACTIVITYAMB_STATUS_INTEREST_REGISTERED ||
                               sc == ACTIVITYAMB_STATUS_POSITION_ACCEPTED;
                    })
                    .ToList();

                if (!ambassadorsForFeedback.Any())
                {
                    if (tracer != null)
                        tracer.Trace("No ambassadors needing feedback for activity {0}", activity.Id);
                    continue;
                }

                // 5. Set these ambassadors to “Position Awaiting Feedback”
                UpdateAmbActivity(orgService, ambassadorsForFeedback);

                // 6. For each such ambassador:
                foreach (var amb in ambassadorsForFeedback)
                {
                    var contactRef = amb.GetAttributeValue<EntityReference>(FIELD_ACTIVITYAMB_CONTACT_LOOKUP);
                    if (contactRef == null)
                    {
                        if (tracer != null)
                            tracer.Trace("ActivityAmbassador {0} has no contact; skipping.", amb.Id);
                        continue;
                    }

                    // 6.a. Create Activity Feedback
                    var feedbackRef = CreateActivityFeedback(orgService, activity, amb, contactRef);

                    // 6.b. Create Notification
                    var subject = $"Feedback requested for activity: {activity.GetAttributeValue<string>(FIELD_ACTIVITY_SUBJECT)}";
                    var message = "Please provide feedback for the activity you recently participated in.";
                    CreateNotification(orgService, contactRef, feedbackRef, subject, message);

                    // 6.c. Update contact last activity date
                    var endDate = activity.GetAttributeValue<DateTime?>(FIELD_ACTIVITY_ENDDATE) ?? DateTime.UtcNow;
                    UpdateContact(orgService, contactRef, endDate);
                }
            }
        }

        #region Helper methods

        /// Returns activities where the end date is in the past and statecode = Open.
        /// Adjust the "LastXDays" value if the business wants a different window.
        private List<Entity> GetActivitiesToProcess(IOrganizationService orgService)
        {
            var query = new QueryExpression(ENTITY_ACTIVITY)
            {
                ColumnSet = new ColumnSet(FIELD_ACTIVITY_ID, FIELD_ACTIVITY_SUBJECT, FIELD_ACTIVITY_ENDDATE),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression(FIELD_ACTIVITY_ENDDATE, ConditionOperator.LastXDays, 30),
                        new ConditionExpression(FIELD_ACTIVITY_STATECODE, ConditionOperator.Equal, ACTIVITY_STATE_OPEN)
                    }
                }
            };

            var results = orgService.RetrieveMultiple(query);
            return results.Entities.ToList();
        }

        /// Get all Activity Ambassador records for a given Activity.
        public List<Entity> GetActivityAmbassadors(IOrganizationService orgService, Guid activityId)
        {
            try
            {
                var query = new QueryExpression(ENTITY_ACTIVITYAMBASSADOR)
                {
                    ColumnSet = new ColumnSet(
                        FIELD_ACTIVITYAMB_CONTACT_LOOKUP,
                        FIELD_ACTIVITYAMB_STATECODE,
                        FIELD_ACTIVITYAMB_STATUSCODE)
                };

                query.Criteria.AddCondition(FIELD_ACTIVITYAMB_ACTIVITY_LOOKUP, ConditionOperator.Equal, activityId);

                var results = orgService.RetrieveMultiple(query);
                return results.Entities.ToList();
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in GetActivityAmbassadors function, Plugin: PostActivityProcess " + ex.Message, ex);
            }
        }

        /// Sets the Activity to "Completed" with either "Completed" or "Did not run"
        /// based on whether there are any active Activity Ambassadors.
        public void SetActivityStatus(IOrganizationService orgService, Entity activity, List<Entity> ambassadors)
        {
            bool anyActive = ambassadors.Any(a =>
                a.GetAttributeValue<OptionSetValue>(FIELD_ACTIVITYAMB_STATECODE)?.Value == ACTIVITYAMB_STATE_ACTIVE);

            var update = new Entity(ENTITY_ACTIVITY) { Id = activity.Id };

            update[FIELD_ACTIVITY_STATECODE] = new OptionSetValue(ACTIVITY_STATE_COMPLETED);
            update[FIELD_ACTIVITY_STATUSCODE] = new OptionSetValue(
                anyActive ? ACTIVITY_STATUS_COMPLETED : ACTIVITY_STATUS_DID_NOT_RUN);

            orgService.Update(update);
        }

        /// Sets all provided Activity Ambassadors to "Position Awaiting Feedback".
        public void UpdateAmbActivity(IOrganizationService orgService, List<Entity> ambassadorsForFeedback)
        {
            foreach (var amb in ambassadorsForFeedback)
            {
                var update = new Entity(ENTITY_ACTIVITYAMBASSADOR) { Id = amb.Id };
                update[FIELD_ACTIVITYAMB_STATUSCODE] =
                    new OptionSetValue(ACTIVITYAMB_STATUS_AWAITING_FEEDBACK);
                orgService.Update(update);
            }
        }

        /// Creates an Activity Feedback record for the given activity & contact.
        /// Returns a reference to the created feedback.
        public EntityReference CreateActivityFeedback(
           IOrganizationService orgService,
           Entity activity,
           Entity ambassador,
           EntityReference contactRef)
        {
            if (contactRef == null)
                throw new InvalidPluginExecutionException("Contact reference is required to create Activity Feedback.");

            // Retrieve multi-select "sic_websiteaccounttype"
            var contact = orgService.Retrieve(
                "contact",
                contactRef.Id,
                new ColumnSet("sic_websiteaccounttype"));

            // Multi-select option set → OptionSetValueCollection
            var typeCollection = contact.GetAttributeValue<OptionSetValueCollection>("sic_websiteaccounttype");

            int? contactType = null;

            if (typeCollection != null && typeCollection.Count > 0)
                contactType = typeCollection[0].Value;  // pick the first selected value

            int? participantTypeValue = null;

            // Map multi-select item → participant type
            switch (contactType)
            {
                case 157430000: // STEM Ambassador
                    participantTypeValue = 1; // Ambassador
                    break;

                case 157430003: // Teacher
                    participantTypeValue = 2; // Teacher
                    break;

                case 157430001: // Youth Group Leader
                    participantTypeValue = 3; // Youth Group Leader
                    break;

                default:
                    // No mapping required for Employer / International/other
                    break;
            }

            var feedback = new Entity(ENTITY_ACTIVITYFEEDBACK);

            feedback[FIELD_FEEDBACK_CONTACT_LOOKUP] = contactRef;
            feedback[FIELD_FEEDBACK_ACTIVITY_LOOKUP] = new EntityReference(ENTITY_ACTIVITY, activity.Id);
            feedback[FIELD_FEEDBACK_ACTIVITYAMB_LOOKUP] = new EntityReference(ENTITY_ACTIVITYAMBASSADOR, ambassador.Id);
            feedback[FIELD_FEEDBACK_STATECODE] = new OptionSetValue(FEEDBACK_STATE_ACTIVE);
            feedback[FIELD_FEEDBACK_STATUSCODE] = new OptionSetValue(FEEDBACK_STATUS_AWAITING);

            if (participantTypeValue.HasValue)
            {
                feedback["sam_participanttype"] = new OptionSetValue(participantTypeValue.Value);
            }

            var id = orgService.Create(feedback);
            return new EntityReference(ENTITY_ACTIVITYFEEDBACK, id);
        }



        /// Creates a Notification regarding the Activity Feedback.
        public void CreateNotification(
            IOrganizationService orgService,
            EntityReference contactRef,
            EntityReference feedbackRef,
            string subject,
            string message)
        {
            var notification = new Entity(ENTITY_NOTIFICATION);

            notification[FIELD_NOTIFICATION_SUBJECT] = subject;
            notification[FIELD_NOTIFICATION_DESCRIPTION] = message;
            notification[FIELD_NOTIFICATION_REGARDING] = feedbackRef;

            var toParty = new Entity("activityparty");
            toParty["partyid"] = contactRef;   // the contact you’re sending to

            var toCollection = new EntityCollection(new List<Entity> { toParty });
            notification[FIELD_NOTIFICATION_TO] = toCollection;

            orgService.Create(notification);
        }

        /// Updates the Contact's "Last Activity Date" to the specified date.
        public void UpdateContact(
            IOrganizationService orgService,
            EntityReference contactRef,
            DateTime lastActivityDate)
        {
            var update = new Entity(ENTITY_CONTACT) { Id = contactRef.Id };
            update[FIELD_CONTACT_LAST_ACTIVITY] = lastActivityDate;
            orgService.Update(update);
        }

        #endregion
    }
}
