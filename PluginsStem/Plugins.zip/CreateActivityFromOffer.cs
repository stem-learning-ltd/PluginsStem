﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;

namespace PluginsStem
{
    public class CreateActivityFromOffer : IPlugin
    {
        private const string SAM_OFFER_LOGICAL_NAME = "sam_offer";
        private const string SAM_ACTIVITY_LOGICAL_NAME = "sam_ambassadoractivity";
        private const string ACTIVITY_NAME_COL = "subject";
        private const string ACTIVITY_DESC_COL = "description";
        private const string ACTIVITY_TYPE_COL = "sam_activitytype";
        private const string ACTIVITY_LOOKUP_ON_ACTIVITY = "sam_offer";
        private const string AREAS_OF_EXPERTISE_COL = "sam_areasofexpertise";

        // Activity Ambassador bits
        private const string ACTIVITYAMB_ENTITY = "sam_activityambassador";
        private const string ACTIVITYAMB_ACTIVITY_LOOKUP = "sam_ambassadoractivity";
        private const string ACTIVITYAMB_CONTACT_LOOKUP = "sam_ambassador";

        // Status reason value for "Position Accepted"
        private const int ACTIVITYAMB_STATE_ACTIVE = 0;
        private const int ACTIVITYAMB_STATUS_POSITION_ACCEPTED = 999990002;

        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                var recordIdStr = context.InputParameters["recordID"] as string;
                var name = context.InputParameters["name"] as string ?? string.Empty;
                var description = context.InputParameters["description"] as string ?? string.Empty;

                int activityType = 0;
                if (context.InputParameters.Contains("activityType") && context.InputParameters["activityType"] != null)
                    activityType = Convert.ToInt32(context.InputParameters["activityType"]);

                var connectToJson = context.InputParameters.Contains("connectToIDs")
                    ? context.InputParameters["connectToIDs"] as string
                    : "[]";

                var offerOwnerIdStr = context.InputParameters.Contains("offerOwnerID")
                    ? context.InputParameters["offerOwnerID"] as string
                    : null;

                // NEW: areas of expertise from action input (string)
                var areasString = context.InputParameters.Contains("areasOfExpertise")
                    ? context.InputParameters["areasOfExpertise"] as string
                    : null;

                if (string.IsNullOrWhiteSpace(recordIdStr))
                    throw new InvalidPluginExecutionException("recordID is required.");

                var offerId = Guid.Parse(recordIdStr);
                var connectToIds = JsonConvert.DeserializeObject<List<Guid>>(connectToJson) ?? new List<Guid>();

                // Always retrieve the offer once so we can reuse fields (owner + areasOfExpertise)
                var offer = service.Retrieve(
                    SAM_OFFER_LOGICAL_NAME,
                    offerId,
                    new ColumnSet("sam_offerowner", AREAS_OF_EXPERTISE_COL));

                // Build OptionSetValueCollection for sam_areasofexpertise
                OptionSetValueCollection areasCollection = null;

                if (!string.IsNullOrWhiteSpace(areasString))
                {
                    // Parse comma/semicolon/space separated list of ints
                    var parts = areasString
                        .Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    var list = new List<OptionSetValue>();
                    foreach (var p in parts)
                    {
                        if (int.TryParse(p, out var val))
                        {
                            list.Add(new OptionSetValue(val));
                        }
                    }

                    if (list.Count > 0)
                        areasCollection = new OptionSetValueCollection(list);
                }
                else
                {
                    // Fallback: copy from offer multi-select if present
                    areasCollection = offer.GetAttributeValue<OptionSetValueCollection>(AREAS_OF_EXPERTISE_COL);
                }

                // Create Activity
                var activity = new Entity(SAM_ACTIVITY_LOGICAL_NAME);
                activity[ACTIVITY_NAME_COL] = name;
                activity[ACTIVITY_DESC_COL] = description;
                activity[ACTIVITY_TYPE_COL] = new OptionSetValue(activityType);
                activity[ACTIVITY_LOOKUP_ON_ACTIVITY] = new EntityReference(SAM_OFFER_LOGICAL_NAME, offerId);

                if (areasCollection != null && areasCollection.Count > 0)
                {
                    activity[AREAS_OF_EXPERTISE_COL] = areasCollection;
                }

                var activityId = service.Create(activity);

                // Create Connections
                foreach (var accountId in connectToIds)
                {
                    var connection = new Entity("connection");
                    connection["record1id"] = new EntityReference(SAM_ACTIVITY_LOGICAL_NAME, activityId);
                    connection["record2id"] = new EntityReference("account", accountId);
                    connection["sam_type"] = new OptionSetValue(3);
                    connection["effectivestart"] = DateTime.UtcNow;
                    connection["description"] = $"Created with activity {activityId}";
                    service.Create(connection);
                }

                EntityReference ownerRef = null;

                // 1) Try to use the id passed from JS (offerOwnerID)
                if (!string.IsNullOrWhiteSpace(offerOwnerIdStr) &&
                    Guid.TryParse(offerOwnerIdStr, out Guid ownerGuidFromParam))
                {
                    ownerRef = new EntityReference("contact", ownerGuidFromParam);
                }
                else
                {
                    // 2) Fallback: read sam_offerowner from the offer record itself
                    ownerRef = offer.GetAttributeValue<EntityReference>("sam_offerowner");
                }

                if (ownerRef != null)
                {
                    var activityAmbassador = new Entity(ACTIVITYAMB_ENTITY);
                    activityAmbassador[ACTIVITYAMB_ACTIVITY_LOOKUP] =
                        new EntityReference(SAM_ACTIVITY_LOGICAL_NAME, activityId);
                    activityAmbassador[ACTIVITYAMB_CONTACT_LOOKUP] = ownerRef;

                    activityAmbassador["statecode"] = new OptionSetValue(ACTIVITYAMB_STATE_ACTIVE);
                    activityAmbassador["statuscode"] =
                        new OptionSetValue(ACTIVITYAMB_STATUS_POSITION_ACCEPTED);

                    service.Create(activityAmbassador);
                }
                else
                {
                    trace?.Trace("CreateActivityFromOffer: No offer owner found; ActivityAmbassador not created.");
                }

                // return activity id
                context.OutputParameters["activityID"] = activityId.ToString();
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"CreateActivityFromOffer failed: {ex.Message}", ex);
            }
        }
    }
}
