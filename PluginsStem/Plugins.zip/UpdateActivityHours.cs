﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsStem
{
    public class UpdateActivityHoursFromAmbassadorStatus : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // Only on Update of sam_activityambassador
                if (!context.InputParameters.Contains("Target"))
                    return;

                var target = context.InputParameters["Target"] as Entity;
                if (target == null || target.LogicalName != "sam_activityambassador")
                    return;

                if (context.MessageName != "Update")
                    return;

                // Avoid recursion
                if (context.Depth > 1)
                    return;

                // PreImage for old status / lookups
                Entity preImage = null;
                if (context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage"))
                {
                    preImage = context.PreEntityImages["PreImage"];
                }

                // New and old statuscode
                var newStatus = GetStatusCode(target, preImage);
                var oldStatus = GetOldStatusCode(preImage);

                const int STATUS_POSITION_AWAITING_FEEDBACK = 999990003;
                const int STATUS_POSITION_FINISHED = 999990007;

                bool isTargetStatus =
                    newStatus == STATUS_POSITION_AWAITING_FEEDBACK ||
                    newStatus == STATUS_POSITION_FINISHED;

                // Only react when status changes TO one of the target statuses
                if (!isTargetStatus || newStatus == oldStatus)
                {
                    trace?.Trace("UpdateActivityHoursFromAmbassadorStatus: status not changed to target values; exiting.");
                    return;
                }

                // 1) Update sam_activityhours on this Activity Ambassador
                UpdateActivityAmbassadorHours(service, trace, target, preImage);

                // 2) Update sam_ambassadoractivityhours on the Ambassador (contact)
                UpdateContactTotalActivityHours(service, trace, target, preImage);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in UpdateActivityHoursFromAmbassadorStatus plugin: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Reads the current statuscode (new value) from Target or PreImage.
        /// </summary>
        private static int GetStatusCode(Entity target, Entity preImage)
        {
            var sc = target.GetAttributeValue<OptionSetValue>("statuscode");
            if (sc != null) return sc.Value;

            var pre = preImage?.GetAttributeValue<OptionSetValue>("statuscode");
            return pre?.Value ?? -1;
        }

        /// <summary>
        /// Reads the old statuscode from PreImage.
        /// </summary>
        private static int GetOldStatusCode(Entity preImage)
        {
            var pre = preImage?.GetAttributeValue<OptionSetValue>("statuscode");
            return pre?.Value ?? -1;
        }

        /// <summary>
        /// For the current Activity Ambassador, reads the related activity's actualdurationminutes,
        /// converts to hours (rounded), and writes sam_activityhours on the ambassador.
        /// </summary>
        private void UpdateActivityAmbassadorHours(
            IOrganizationService service,
            ITracingService trace,
            Entity target,
            Entity preImage)
        {
            // Lookup to sam_ambassadoractivity
            var activityRef =
                target.GetAttributeValue<EntityReference>("sam_ambassadoractivity") ??
                preImage?.GetAttributeValue<EntityReference>("sam_ambassadoractivity");

            if (activityRef == null)
            {
                trace?.Trace("UpdateActivityHoursFromAmbassadorStatus: sam_ambassadoractivity is null; skipping amb hours update.");
                return;
            }

            // Retrieve the activity and get actualdurationminutes (int minutes)
            var activity = service.Retrieve(
                "sam_ambassadoractivity",
                activityRef.Id,
                new ColumnSet("actualdurationminutes"));

            int minutes = activity.GetAttributeValue<int?>("actualdurationminutes") ?? 0;

            int hours = ConvertMinutesToRoundedHours(minutes);

            var ambToUpdate = new Entity("sam_activityambassador")
            {
                Id = target.Id
            };

            ambToUpdate["sam_activityhours"] = hours;

            service.Update(ambToUpdate);

            trace?.Trace(
                "UpdateActivityHoursFromAmbassadorStatus: set sam_activityhours={0} (from {1} minutes) on ActivityAmbassador {2}",
                hours, minutes, target.Id);
        }

        /// <summary>
        /// For the ambassador (contact) on this Activity Ambassador, sums all activity durations
        /// (for ambassadors with status Position Awaiting Feedback or Position Finished),
        /// converts each to hours (rounded) and stores the total in sam_ambassadoractivityhours on contact.
        /// </summary>
        private void UpdateContactTotalActivityHours(
            IOrganizationService service,
            ITracingService trace,
            Entity target,
            Entity preImage)
        {
            // Lookup to ambassador contact
            var contactRef =
                target.GetAttributeValue<EntityReference>("sam_ambassador") ??
                preImage?.GetAttributeValue<EntityReference>("sam_ambassador");

            if (contactRef == null)
            {
                trace?.Trace("UpdateActivityHoursFromAmbassadorStatus: sam_ambassador is null; skipping contact update.");
                return;
            }

            Guid contactId = contactRef.Id;

            // Get all ambassadors for this contact with relevant statuses
            List<Entity> ambassadors = GetAmbassadorsForContactWithStatuses(service, contactId);

            // Cache activity durations to avoid retrieving same activity multiple times
            var durationCache = new Dictionary<Guid, int>();
            int totalHours = 0;

            foreach (var amb in ambassadors)
            {
                var actRef = amb.GetAttributeValue<EntityReference>("sam_ambassadoractivity");
                if (actRef == null) continue;

                int minutes;

                if (!durationCache.TryGetValue(actRef.Id, out minutes))
                {
                    var activity = service.Retrieve(
                        "sam_ambassadoractivity",
                        actRef.Id,
                        new ColumnSet("actualdurationminutes"));

                    minutes = activity.GetAttributeValue<int?>("actualdurationminutes") ?? 0;
                    durationCache[actRef.Id] = minutes;
                }

                totalHours += ConvertMinutesToRoundedHours(minutes);
            }

            var contactToUpdate = new Entity("contact")
            {
                Id = contactId
            };

            contactToUpdate["sam_ambassadoractivityhours"] = totalHours;

            service.Update(contactToUpdate);

            trace?.Trace(
                "UpdateActivityHoursFromAmbassadorStatus: set sam_ambassadoractivityhours={0} on contact {1}",
                totalHours, contactId);
        }

        /// <summary>
        /// Returns all sam_activityambassador records for a given contact
        /// where statuscode is Position Awaiting Feedback or Position Finished,
        /// using paging similar to getActiveDBSRecords pattern.
        /// </summary>
        private List<Entity> GetAmbassadorsForContactWithStatuses(IOrganizationService orgService, Guid contactId)
        {
            var results = new EntityCollection();
            var resultsTemp = new EntityCollection();

            const int STATUS_POSITION_AWAITING_FEEDBACK = 999990003;
            const int STATUS_POSITION_FINISHED = 999990007;

            try
            {
                var query = new QueryExpression("sam_activityambassador");

                query.ColumnSet = new ColumnSet("statuscode", "sam_ambassadoractivity");

                // Filter by ambassador (contact)
                query.Criteria.AddCondition("sam_ambassador", ConditionOperator.Equal, contactId);

                // statuscode in (Position Awaiting Feedback, Position Finished)
                var statusFilter = new FilterExpression(LogicalOperator.Or);
                statusFilter.AddCondition("statuscode", ConditionOperator.Equal, STATUS_POSITION_AWAITING_FEEDBACK);
                statusFilter.AddCondition("statuscode", ConditionOperator.Equal, STATUS_POSITION_FINISHED);

                query.Criteria.AddFilter(statusFilter);

                query.PageInfo = new PagingInfo
                {
                    Count = 5000,
                    PageNumber = 1,
                    PagingCookie = null
                };

                do
                {
                    resultsTemp = orgService.RetrieveMultiple(query);
                    results.Entities.AddRange(resultsTemp.Entities);
                    query.PageInfo.PageNumber++;
                    query.PageInfo.PagingCookie = resultsTemp.PagingCookie;
                }
                while (resultsTemp.MoreRecords);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in GetAmbassadorsForContactWithStatuses, plugin UpdateActivityHoursFromAmbassadorStatus: " + ex.Message, ex);
            }

            return results.Entities.ToList();
        }

        /// <summary>
        /// Converts minutes to rounded hours:
        ///  - 0 minutes  => 0
        ///  - 1-60 min   => 1
        ///  - >60 min    => ceiling(minutes / 60.0)
        /// </summary>
        private int ConvertMinutesToRoundedHours(int minutes)
        {
            if (minutes <= 0)
                return 0;

            // raw hours as double
            double hours = minutes / 60.0;

            if (hours <= 1.0)
                return 1; // any non-zero up to 60 minutes -> 1 hour

            return (int)Math.Ceiling(hours);
        }
    }
}
