﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsStem
{
    public class SetActivityAmbassadorHub : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                if (context.Depth > 1)
                    return;

                if (!context.InputParameters.Contains("Target"))
                    return;

                var target = context.InputParameters["Target"] as Entity;
                if (target == null || target.LogicalName != "sam_activityambassador")
                    return;

                if (context.MessageName != "Create" && context.MessageName != "Update")
                    return;

                Entity preImage = null;
                if (context.MessageName == "Update" &&
                    context.PreEntityImages != null &&
                    context.PreEntityImages.Contains("PreImage"))
                {
                    preImage = context.PreEntityImages["PreImage"];
                }

                var ambassadorRef =
                    target.GetAttributeValue<EntityReference>("sam_ambassador") ??
                    preImage?.GetAttributeValue<EntityReference>("sam_ambassador");

                if (ambassadorRef == null)
                {
                    trace?.Trace("SetActivityAmbassadorHub: no sam_ambassador on record, nothing to do.");
                    return;
                }

                // Retrieve the contact to get sam_hub
                var contact = service.Retrieve(
                    "contact",
                    ambassadorRef.Id,
                    new ColumnSet("sam_hub"));

                var hubRef = contact.GetAttributeValue<EntityReference>("sam_hub");
                if (hubRef == null)
                {
                    trace?.Trace("SetActivityAmbassadorHub: contact {0} has no sam_hub set.", ambassadorRef.Id);
                    return;
                }

                // Update the Activity Ambassador with the hub
                var activityAmbassadorToUpdate = new Entity("sam_activityambassador");
                activityAmbassadorToUpdate.Id = context.PrimaryEntityId;

                activityAmbassadorToUpdate["sam_activityambassadorhub"] = hubRef;

                service.Update(activityAmbassadorToUpdate);

                trace?.Trace(
                    "SetActivityAmbassadorHub: set sam_activityambassadorhub on {0} to hub {1}.",
                    context.PrimaryEntityId, hubRef.Id);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in SetActivityAmbassadorHub plugin: " + ex.Message, ex);
            }
        }
    }
}
