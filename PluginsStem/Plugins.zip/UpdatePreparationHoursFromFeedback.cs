﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginsStem
{
    public class UpdatePreparationHoursFromFeedback : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                if (!context.InputParameters.Contains("Target"))
                    return;

                var target = context.InputParameters["Target"] as Entity;
                if (target == null || target.LogicalName != "sam_activityfeedback")
                    return;

                if (context.Depth > 1)
                    return;

                if (context.MessageName != "Update")
                    return;

                Entity preImage = null;
                if (context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage"))
                {
                    preImage = context.PreEntityImages["PreImage"];
                }

                // New status
                int newStatus = GetStatusCode(target, preImage);
                int oldStatus = GetOldStatusCode(preImage);

                // take only Completed (999990002)
                const int STATUS_COMPLETED = 999990002;
                if (newStatus != STATUS_COMPLETED || oldStatus == STATUS_COMPLETED)
                {
                    trace?.Trace("UpdatePreparationHoursFromFeedback: status not changed to Completed; exiting.");
                    return;
                }

                // 1) Update Activity Ambassador with sam_preparationhours
                UpdateActivityAmbassadorPreparation(service, trace, target, preImage);

                // 2) Update Contact with sum of all preparationtime (Completed)
                UpdateContactTotalPreparation(service, trace, target, preImage);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in UpdatePreparationHoursFromFeedback plugin: " + ex.Message, ex);
            }
        }

        private static int GetStatusCode(Entity target, Entity preImage)
        {
            var sc = target.GetAttributeValue<OptionSetValue>("statuscode");
            if (sc != null) return sc.Value;

            var pre = preImage?.GetAttributeValue<OptionSetValue>("statuscode");
            return pre?.Value ?? -1;
        }

        private static int GetOldStatusCode(Entity preImage)
        {
            var pre = preImage?.GetAttributeValue<OptionSetValue>("statuscode");
            return pre?.Value ?? -1;
        }

        private void UpdateActivityAmbassadorPreparation(
            IOrganizationService service,
            ITracingService trace,
            Entity target,
            Entity preImage)
        {
            var ambRef =
                target.GetAttributeValue<EntityReference>("sam_activityambassador") ??
                preImage?.GetAttributeValue<EntityReference>("sam_activityambassador");

            if (ambRef == null)
            {
                trace?.Trace("UpdatePreparationHoursFromFeedback: sam_activityambassador is null; skipping amb update.");
                return;
            }

            int prepHours = 0;

            if (target.Attributes.Contains("sam_preparationtime"))
            {
                prepHours = target.GetAttributeValue<int?>("sam_preparationtime") ?? 0;
            }
            else if (preImage != null && preImage.Attributes.Contains("sam_preparationtime"))
            {
                prepHours = preImage.GetAttributeValue<int?>("sam_preparationtime") ?? 0;
            }

            var ambToUpdate = new Entity("sam_activityambassador");
            ambToUpdate.Id = ambRef.Id;

            ambToUpdate["sam_preparationhours"] = prepHours;

            service.Update(ambToUpdate);

            trace?.Trace("UpdatePreparationHoursFromFeedback: set sam_preparationhours={0} on ActivityAmbassador {1}",
                prepHours, ambRef.Id);
        }

        private void UpdateContactTotalPreparation(
            IOrganizationService service,
            ITracingService trace,
            Entity target,
            Entity preImage)
        {
            var contactRef =
                target.GetAttributeValue<EntityReference>("sam_contact") ??
                preImage?.GetAttributeValue<EntityReference>("sam_contact");

            if (contactRef == null)
            {
                trace?.Trace("UpdatePreparationHoursFromFeedback: sam_contact is null; skipping contact update.");
                return;
            }

            Guid contactId = contactRef.Id;

            List<Entity> completedFeedbacks = GetCompletedFeedbacksForContact(service, contactId);

            decimal totalPrep = completedFeedbacks.Sum(fb =>
                fb.GetAttributeValue<int?>("sam_preparationtime") ?? 0);

            var contactToUpdate = new Entity("contact");
            contactToUpdate.Id = contactId;

            contactToUpdate["sam_ambassadorpreparationhours"] = totalPrep;

            service.Update(contactToUpdate);

            trace?.Trace("UpdatePreparationHoursFromFeedback: set sam_ambassadorpreparationhours={0} on contact {1}",
                totalPrep, contactId);
        }


        private List<Entity> GetCompletedFeedbacksForContact(IOrganizationService orgService, Guid contactId)
        {
            var results = new EntityCollection();
            var resultsTemp = new EntityCollection();

            const int STATUS_COMPLETED = 999990002;

            try
            {
                var query = new QueryExpression("sam_activityfeedback");

                query.ColumnSet = new ColumnSet("sam_preparationtime", "statuscode", "sam_contact");

                query.Criteria.AddCondition("sam_contact", ConditionOperator.Equal, contactId);
                query.Criteria.AddCondition("statuscode", ConditionOperator.Equal, STATUS_COMPLETED);

                query.PageInfo = new PagingInfo
                {
                    Count = 5000,
                    PageNumber = 1,
                    PagingCookie = null
                };

                do
                {
                    resultsTemp = orgService.RetrieveMultiple(query);
                    results.Entities.AddRange(resultsTemp.Entities);
                    query.PageInfo.PageNumber++;
                    query.PageInfo.PagingCookie = resultsTemp.PagingCookie;
                }
                while (resultsTemp.MoreRecords);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    "Error in GetCompletedFeedbacksForContact, plugin UpdatePreparationHoursFromFeedback: " + ex.Message, ex);
            }

            return results.Entities.ToList();
        }
    }
}
